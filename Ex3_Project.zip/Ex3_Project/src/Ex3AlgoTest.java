import static org.junit.jupiter.api.Assertions.*;

class Ex3AlgoTest {



}